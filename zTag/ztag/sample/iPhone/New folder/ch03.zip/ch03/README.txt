about.html                           // Data page to be accessed via Ajax from iphone.html
blog.html                            // Data page to be accessed via Ajax from iphone.html
consulting-clinic.html               // Data page to be accessed via Ajax from iphone.html
development.html                     // Data page to be accessed via Ajax from iphone.html
images/back_button.png               // Border image referenced in iphone.css
images/back_button_clicked.png       // Border image referenced in iphone.css
images/button.png                    // Border image referenced in iphone.css
images/button_clicked.png            // Border image referenced in iphone.css
index.html                           // Data page to be accessed via Ajax from iphone.html
iphone.css                           // CSS for iPhone browser styles referenced in iphone.html
iphone.html                          // Main page; this is the page to load in your browser
iphone.js                            // Custom JavaScript referenced in iphone.html
jquery.js                            // Public jQuery JavaScript library referenced in iphone.html
myCustomIcon.png                     // Web Clip Icon referenced in iphone.html
myCustomStartupGraphic.png           // Startup Graphic (for full screen mode) referenced in iphone.html
on-call.html                         // Data page to be accessed via Ajax from iphone.html
