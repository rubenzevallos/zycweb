//
//  File.m
//  PhoneGap
//
//  Created by Nitobi on 19/12/08.
//  Copyright 2008 Nitobi. All rights reserved.
//

#import "File.h"


@implementation File

@end
