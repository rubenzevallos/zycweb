//
//  File.h
//  PhoneGap
//
//  Created by Nitobi on 19/12/08.
//  Copyright 2008 Nitobi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface File : NSObject {
	
}



@end
