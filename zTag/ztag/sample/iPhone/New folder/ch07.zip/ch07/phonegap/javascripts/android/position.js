function Position(coords, timestamp)
{
	this.coords = coords;
	this.timestamp = timestamp;
}
