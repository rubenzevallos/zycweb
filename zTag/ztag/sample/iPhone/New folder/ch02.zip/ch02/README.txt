desktop.css                 // CSS stub file for desktop browsers styles referenced in index.html
explorer.css                // CSS stub file for Internet Explorer styles referenced in index.html
images/button.png           // Border image referenced in iphone.css
images/button_clicked.png   // Border image referenced in iphone.css
images/manga.png            // Sidebar graphic referenced in index.html
index.html                  // The main page; this is the page you would load in your browser
iphone.css                  // CSS for iPhone browser styles referenced in index.html
iphone.js                   // Custom JavaScript referenced in index.html
jquery.js                   // Public jQuery JavaScript library referenced in index.html
