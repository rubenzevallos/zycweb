<div class="pacrudHeader">
	<div class="pacrudHeaderLeft">:shortcuts:</div>
	<div class="pacrudHeaderRight">:logoff:</div>
	<div class="pacrudHeaderCenter">:appIdent: - :appName:</div>
</div>
<div class="pacrudBody">
	<div class="pacrudMenuArea">:menu:</div>
	<div class="pacrudDesktop">:desktop:</div>
</div>
<div class="pacrudFooter">:footer:</div>
