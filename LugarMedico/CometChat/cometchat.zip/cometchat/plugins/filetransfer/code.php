<?php
$plugininfo = array('filetransfer','Send a file');