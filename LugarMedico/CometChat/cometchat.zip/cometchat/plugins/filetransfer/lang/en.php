<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$filetransfer_language[0] = 'Send a file';
$filetransfer_language[1] = 'Which file would you like to send?';
$filetransfer_language[2] = 'Please select a file by using the button below.';
$filetransfer_language[3] = '<b>WARNING:</b> Do not send copyrighted material for which you don\'t own the rights or have permission from the owner.';
$filetransfer_language[4] = 'Send file';
$filetransfer_language[5] = 'has sent you a file';
$filetransfer_language[6] = 'Click here to download the file';
$filetransfer_language[7] = 'has successfully sent a file';
$filetransfer_language[8] = 'File sent successfully. Closing Window.';
$filetransfer_language[9] = 'has shared a file';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////