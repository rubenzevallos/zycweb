<?php
$plugininfo = array('chathistory','Chat History');