<?php
$plugininfo = array('clearconversation','Clear Conversation');