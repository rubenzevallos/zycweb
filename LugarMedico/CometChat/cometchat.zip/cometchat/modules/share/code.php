<?php
$trayiconinfo = array('share','Share This Page');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnc2hhcmUnLCdTaGFyZSBUaGlzIFBhZ2UnLCdtb2R1bGVzL3NoYXJlL2luZGV4LnBocCcsJ19wb3B1cCcsJzM0MCcsJzUwJywnJywnMScpOw';