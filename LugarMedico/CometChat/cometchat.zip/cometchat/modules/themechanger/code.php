<?php
$trayiconinfo = array('themechanger','Change Theme');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgndGhlbWVjaGFuZ2VyJywnQ2hhbmdlIFRoZW1lJywnbW9kdWxlcy90aGVtZWNoYW5nZXIvaW5kZXgucGhwJywnX3BvcHVwJywnMjAwJywnMTAwJywnJywnMScpOw';