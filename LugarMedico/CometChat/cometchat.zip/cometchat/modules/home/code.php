<?php
$trayiconinfo = array('home','Home');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnaG9tZScsJ0hvbWUnLCcvJywnJywnJywnJywnJywnJyk7';