<?php
$trayiconinfo = array('scrolltotop','Scroll To Top');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnc2Nyb2xsdG90b3AnLCdTY3JvbGwgVG8gVG9wJywnamF2YXNjcmlwdDpqcWNjLmNvbWV0Y2hhdC5zY3JvbGxUb1RvcCgpOycsJycsJycsJycsJycsJycpOw';