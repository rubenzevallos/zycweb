<?php

include_once dirname(__FILE__)."/cometchat_init.php";

if ($userid == 0) { exit; }