<?php
// Bump this when updating the zip package
define('YOURLS_VERSION', '1.5');
define('YOURLS_DB_VERSION', '482');
?>