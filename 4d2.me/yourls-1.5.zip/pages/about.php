<?php

echo "This is an About page. Its URL is simply ". YOURLS_SITE ."/about";

?>