<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Site Header Content //-->
<link rel="stylesheet" media="screen" type="text/css" href="/css/site.css" />

<link rel="stylesheet" media="screen" type="text/css" href="/css/home.css" />
<link media="handheld, screen and (max-device-width: 480px)" rel="stylesheet" type="text/css" href="/css/iphone.css" />
<link rel="stylesheet" media="screen" type="text/css" href="/css/tooltip.css" />
<!--[if lt IE 7]>
<link rel="stylesheet" media="screen" type="text/css" href="/css/tooltip-ie.css" />
<![endif]-->


<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Agent Anything  -  anyerrand  |  anytime  |  anywhere</title>
<meta name="description" content="Agent Anything is essentially the eBay of services: People can post any service (task, errand, research, etc.) they need accomplished as well as the price they are willing to pay, and college students can perform these services to get paid." />
<meta name="keywords" content="errand running, errands, new york" />
<meta name="generator" content="concrete5 - 5.4.1" />

<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 1;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/concrete/images";
var CCM_TOOLS_PATH = "/tools/required";
var CCM_REL = "";

</script>

	<link rel="shortcut icon" href="/files/6712/8312/2160/aanew.ico" type="image/x-icon" />
	<link rel="icon" href="/files/6712/8312/2160/aanew.ico" type="image/x-icon" />

<link rel="stylesheet" type="text/css" href="/concrete/css/ccm.base.css?v=2bcecb17ab85a208012e23d6cdc623fe" />
<script type="text/javascript" src="/concrete/js/jquery.js?v=2bcecb17ab85a208012e23d6cdc623fe"></script>
<script type="text/javascript" src="/concrete/js/ccm.base.js?v=2bcecb17ab85a208012e23d6cdc623fe"></script>

<script type="text/javascript" src="/js/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/jquery/jquery.tools.min.js"></script>
<script type="text/javascript" src="/js/site/home.js"></script>

</head>
<body>
<div id="content">
	<div class="header" id="header">
	    <div class="location" id="location-change">Location:&nbsp;&nbsp;<a href="" title="We are currently only serving the New York & New Jersey area. We'll be expanding soon! &lt;b&gt;&lt;a href='/register-your-interest'&gt;Click here to register interest&lt;/a&gt;&lt;/b&gt;">New York & New Jersey (Change)</a></div>
                <div class="links">
                                                           <span class="sign-in"><a href="/login/">Login</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/signup/">Sign Up</a></span>
                                                </div>
                <hr />
    </div>
    <div class="main">
	<h1><img src="/images/home/alogo.gif" title="Agent Anything - anyerrand | anytime | anywhere" alt="Agent Anything" /></h1>
        <div class="boxes" id="boxes">
	    <ol>
		<li>
		    <h2><a href="/errands/post/wizard/" title="Post a Mission"><img src="/images/home/post-mission-button.gif" alt="Post a Mission" /></a></h2>
		</li>
		<li>
		    <h2><a href="/errands/" title="Run a Mission"><img src="/images/home/run-mission-button.gif" alt="Run a Mission" /></a></h2>
                </li>
	    </ol>
	    <div id="run-info-button" title="If you are a college student, you can get paid to run Missions.&lt;br /&gt;&lt;b&gt;&lt;a href='/how-it-works/'&gt;How it works &gt;&gt;&lt;/a&gt;&lt;/b&gt;"></div>
	    <div id="post-info-button" title="Busy? Need something done? Errands? Deliveries? Anything else?&nbsp;&lt;b&gt;Our Agents can do ANYTHING!&nbsp;&lt;a href='/how-it-works/'&gt;How it works &gt;&gt;&lt;/a&gt;&lt;/b&gt;"></div>
        </div>
	<div id="ben-and-jerrys-promotion"><a href="/errands/post/wizard/?promotion=ben-and-jerrys"><img src="/images/home/ben-and-jerrys-promo.png" alt="FREE Ben &amp; Jerry's Mission" /></a></div>
    </div>
</div>
<div class="background-top"></div>
<div class="footer">
	    <div class="center"></div>
    	<div class="left"></div>
        <div class="right"></div>
        <div class="links"><a href="/privacy-policy/">Privacy Policy</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="/terms-of-use/">Terms &amp; Conditions</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="/how-it-works/">How it works</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
	    <a href="/contact-us/">Contact Us</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            &copy; Agent Anything Inc. 2011	    <br />
	    <a href="http://www.facebook.com/pages/New-York-NY/Agent-Anything/156564541026353?v=info" target="_blank"><img src="/images/social-icons/facebook-button.gif" alt="Find us on Facebook"/></a>
	    <a href="http://twitter.com/AgentAnything" target="_blank"><img src="/images/social-icons/twitter-button.gif" alt="Follow us on Twitter" /></a>
	    <script type="text/javascript" src="https://seal.verisign.com/getseal?host_name=www.agentanything.com&amp;size=S&amp;use_flash=YES&amp;use_transparent=YES&amp;lang=en"></script>
	</div>
</div>
<div class="background-base" id="background-base"></div>
<script src="https://static.getclicky.com/js" type="text/javascript"></script>

<script type="text/javascript">clicky.init(247553);</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="https://in.getclicky.com/247553ns.gif" /></p></noscript><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18335145-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script type="text/javascript">
adroll_adv_id = "HAEFJQAYAZGX5FTW6UWEEW";
adroll_pix_id = "7XQQN5PJS5B4LI522ZIZBH";
(function () {
var oldonload = window.onload;
window.onload = function(){
   __adroll_loaded=true;
   var scr = document.createElement("script");
   var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
   scr.setAttribute('async', 'true');
   scr.type = "text/javascript";
   scr.src = host + "/j/roundtrip.js";
   document.documentElement.firstChild.appendChild(scr);
   if(oldonload){oldonload()}};
}());
</script><script type="text/javascript">
  var uservoiceOptions = {
    key: 'agentanything',
    host: 'agentanything.uservoice.com',
    forum: '72301',
    alignment: 'left',
    background_color:'#99cc33',
    text_color: 'white',
    hover_color: '#5a7d14',
    lang: 'en',
    showTab: true
  };
  function _loadUserVoice() {
    var s = document.createElement('script');
    s.src = ("https:" == document.location.protocol ? "https://" : "http://") + "uservoice.com/javascripts/widgets/tab.js";
    document.getElementsByTagName('head')[0].appendChild(s);
  }
  _loadSuper = window.onload;
  window.onload = (typeof window.onload != 'function') ? _loadUserVoice : function() { _loadSuper(); _loadUserVoice(); };
</script>
</body>
</html>