<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	
<!-- Site Header Content //-->

<link rel="stylesheet" media="screen" type="text/css" href="/css/site.css" />
<link media="handheld, screen and (max-device-width: 480px)" rel="stylesheet" type="text/css" href="/css/iphone.css" />
<link rel="stylesheet" media="screen" type="text/css" href="/css/overlays/overlays.css" />


<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Agent Anything :: Run a Mission</title>
<meta name="description" content="If you are a college student, you can get paid to run Missions for people." />
<meta name="keywords" content="college student job, student job, student work" />
<meta name="generator" content="concrete5 - 5.4.1" />

<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 58;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/concrete/images";
var CCM_TOOLS_PATH = "/tools/required";
var CCM_REL = "";

</script>

	<link rel="shortcut icon" href="/files/6712/8312/2160/aanew.ico" type="image/x-icon" />
	<link rel="icon" href="/files/6712/8312/2160/aanew.ico" type="image/x-icon" />

<link rel="stylesheet" type="text/css" href="/concrete/css/ccm.base.css?v=2bcecb17ab85a208012e23d6cdc623fe" />
<script type="text/javascript" src="/concrete/js/jquery.js?v=2bcecb17ab85a208012e23d6cdc623fe"></script>
<script type="text/javascript" src="/concrete/js/ccm.base.js?v=2bcecb17ab85a208012e23d6cdc623fe"></script>
<script type="text/javascript" src="/concrete/js/jquery.ui.js"></script>
<link rel="stylesheet" type="text/css" href="/css/ui-lightness/jquery-ui-1.8.2.custom.css"></script>
<script type="text/javascript" src="/concrete/js/jquery.ui.js"></script>

<script type="text/javascript" src="/js/jquery/jquery.tools.min.js"></script>
<link rel="stylesheet" media="screen" type="text/css" href="/css/tooltip-big.css" />
<!--[if lt IE 7]>
<link rel="stylesheet" media="screen" type="text/css" href="/css/tooltip-big-ie.css" />
<![endif]-->

<script type="text/javascript" src="/js/site/base.js"></script>

<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="http://code.google.com/apis/gears/gears_init.js"></script>
<script type="text/javascript" src="/js/site/errands/view.js"></script>
<link rel="stylesheet" media="screen" type="text/css" href="/css/errands/view.css" />

<script type="text/javascript" src="/js/overlays/base.overlay.js"></script>
<script type="text/javascript" src="/js/overlays/userinfo.overlay.js"></script>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=agentanything"></script>
<script type="text/javascript">
var folderVars = [];
folderVars["uLat"] = 40.75;
folderVars["uLng"] = -73.99;
folderVars["pHdl"] = "errands";
folderVars["uID"] = 0;
folderVars["uType"] = "";
folderVars["uAuthd"] = false;
folderVars["isEmbedded"] = false;
folderVars["jsonPath"] = "/errands/getjsonmission/";
</script>
<script type="text/javascript" src="/js/overlays/missioninfo.overlay.js"></script>

</head>
<body onload="setupPage()">
    <div id="page">
        <div id="content">
                <div id="header">
                        <h1 id="logo"><a href="/" title="Agent Anything"><img src="/images/agentanything-logo.jpg" border="0" alt="Agent Anything - anyerrand | anytime | anywhere" /></a></h1>
                        <div id="navigation" class="navigation">
                            <ol>
                                <li><a href="/" id="home-nav-link">Home<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></a></li>
                                <li><a id="post-nav-link" href="/errands/post/wizard/" >Post Mission<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></a></li>
                                <li><a href="/errands/" id="run-nav-link" class="highlight">Run Mission<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></a></li>
                                <li><a href="/how-it-works/" id="how-nav-link" >How it works<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></a></li>
                                <li><a href="/contact-us/" >Contact Us<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></a></li>
                            </ol>
                        </div>

                        <div id="sign-in">

			    <span id="location-change">Location:&nbsp;&nbsp;<a href="" title="We are currently only serving the New York & New Jersey area. We'll be expanding soon!&lt;br /&gt;&lt;br /&gt;&lt;b&gt;&lt;a href='/register-your-interest'&gt;Click here to register your interest &gt;&gt;&lt;/a&gt;&lt;/b&gt;">New York & New Jersey (Change)</a></span>
			    <br /><br />
                                                    <span class="sign-in"><a href="/login/">Login</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/signup/">Sign Up</a></span>

                        
                        </div>

                        <hr />
			<div id="post-nav" class="nav-drop-down post-drop-down">
			    <div class="top"></div>
			    <div class="content">
				<ol>
				    <li><a href="/how-it-works/client-faqs/how-to-post-a-mission/">How to Post a Mission</a></li>
				    <li><a href="/errands/examples/">Mission Examples</a></li>
				    <!--<li><a href="/how-it-works/client-faqs/mission-pricing-and-our-fees/">Mission Pricing &amp; Our Fees</a></li>!-->
				    <li class="last-item"><a href="/members/?filter=agents">Our Agents</a></li>
				</ol>
			    </div>
			    <div class="bottom"></div>
			</div>

			<div id="run-nav" class="nav-drop-down run-drop-down">
			    <div class="top"></div>
			    <div class="content">
				<ol>
				    <li><a href="/errands/">Find a Mission</a></li>
				    <li class="last-item"><a href="/how-it-works/agent-faqs/how-to-run-a-mission/">How to Run a Mission</a></li>
				</ol>
			    </div>
			    <div class="bottom"></div>
			</div>

			<div id="how-nav" class="nav-drop-down how-drop-down">
			    <div class="top"></div>
			    <div class="content">
				<ol>
				    <li><a href="/how-it-works/">What is Agent Anything?</a></li>
				    <!--<li><a href="/how-it-works/client-faqs/the-mission-process/">The Mission Process</a></li>!-->
				    <li><a href="/how-it-works/client-faqs/">Client FAQs</a></li>
				    <li class="last-item"><a href="/how-it-works/agent-faqs/">Agent FAQs</a></li>
				</ol>
			    </div>
			    <div class="bottom"></div>
			</div>
                </div>
<div style="width:100%;">
			<link rel="alternate" href="http://twitter.com/statuses/user_timeline/196447396.rss" title="directorgreen's Tweets" type="application/rss+xml" />

<!-- Standard Map Code !-->
<script type="text/javascript">
var distance = parseFloat(0);

var CCM_URL_BASE = "/";

function setupMissionMarkers() {

    var latlngbounds = new google.maps.LatLngBounds(); //for auto zoom

    mposition4030 = new google.maps.LatLng(40.75,-73.99);

    latlngbounds.extend(mposition4030);

    mmarkers[4030] = new google.maps.Marker({
			position: mposition4030,
			map: map
	      });
      
    mmarkers[4030].setIcon("/images/errands/markers/marker_grey.png");
        mmarkers[4030].setVisible(false);
        google.maps.event.addListener(mmarkers[4030], 'click', function() {
    getMission(4030);

    });

        var contentString4030 = '<div style="font-size:12px;"><b>Need Clients for my Daycare (Baby Cubs Daycare, Inc.)</b><br />Location: Virtual Mission (Online, Phone, etc)<br />Price: $100.00<br />Due: 1 week</div>';
    
    infowindows[4030] = new google.maps.InfoWindow({
	content: contentString4030,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4030], 'mouseover', function() {
   showMissionInfoWindow(4030);
    });

    google.maps.event.addListener(mmarkers[4030], 'mouseout', function() {
    closeMissionInfoWindow(4030);
    });



    mposition4049 = new google.maps.LatLng(40.721108,-73.987751);

    latlngbounds.extend(mposition4049);

    mmarkers[4049] = new google.maps.Marker({
			position: mposition4049,
			map: map
	      });
      
    mmarkers[4049].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4049], 'click', function() {
    getMission(4049);

    });

        var contentString4049 = '<div style="font-size:12px;"><b>Just bring 10 people to see a new indie band!</b><br />Location: Ludlow St, Manhattan, NY10002<br />Price: $60.00<br />Due: Wednesday 9:30pm<br />Click for more information.</div>';
    
    infowindows[4049] = new google.maps.InfoWindow({
	content: contentString4049,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4049], 'mouseover', function() {
   showMissionInfoWindow(4049);
    });

    google.maps.event.addListener(mmarkers[4049], 'mouseout', function() {
    closeMissionInfoWindow(4049);
    });



    mposition4110 = new google.maps.LatLng(40.75,-73.99);

    latlngbounds.extend(mposition4110);

    mmarkers[4110] = new google.maps.Marker({
			position: mposition4110,
			map: map
	      });
      
    mmarkers[4110].setIcon("/images/errands/markers/marker_grey.png");
        mmarkers[4110].setVisible(false);
        google.maps.event.addListener(mmarkers[4110], 'click', function() {
    getMission(4110);

    });

        var contentString4110 = '<div style="font-size:12px;"><b>Help us write a Business Plan for an Existing Company</b><br />Location: Virtual Mission (Online, Phone, etc)<br />Price: $Offers<br />Due: 2 weeks</div>';
    
    infowindows[4110] = new google.maps.InfoWindow({
	content: contentString4110,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4110], 'mouseover', function() {
   showMissionInfoWindow(4110);
    });

    google.maps.event.addListener(mmarkers[4110], 'mouseout', function() {
    closeMissionInfoWindow(4110);
    });



    mposition4197 = new google.maps.LatLng(40.721108,-73.987751);

    latlngbounds.extend(mposition4197);

    mmarkers[4197] = new google.maps.Marker({
			position: mposition4197,
			map: map
	      });
      
    mmarkers[4197].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4197], 'click', function() {
    getMission(4197);

    });

        var contentString4197 = '<div style="font-size:12px;"><b>Get paid to bring 10 people to see a new indie band!</b><br />Location: Ludlow St, Manhattan, NY10002<br />Price: $60.00<br />Due: Wednesday 10:00pm<br />Click for more information.</div>';
    
    infowindows[4197] = new google.maps.InfoWindow({
	content: contentString4197,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4197], 'mouseover', function() {
   showMissionInfoWindow(4197);
    });

    google.maps.event.addListener(mmarkers[4197], 'mouseout', function() {
    closeMissionInfoWindow(4197);
    });



    mposition4201 = new google.maps.LatLng(40.75,-73.99);

    latlngbounds.extend(mposition4201);

    mmarkers[4201] = new google.maps.Marker({
			position: mposition4201,
			map: map
	      });
      
    mmarkers[4201].setIcon("/images/errands/markers/marker_grey.png");
        mmarkers[4201].setVisible(false);
        google.maps.event.addListener(mmarkers[4201], 'click', function() {
    getMission(4201);

    });

        var contentString4201 = '<div style="font-size:12px;"><b>Edit text on www</b><br />Location: Virtual Mission (Online, Phone, etc)<br />Price: $12.00<br />Due: Tuesday 10:00pm</div>';
    
    infowindows[4201] = new google.maps.InfoWindow({
	content: contentString4201,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4201], 'mouseover', function() {
   showMissionInfoWindow(4201);
    });

    google.maps.event.addListener(mmarkers[4201], 'mouseout', function() {
    closeMissionInfoWindow(4201);
    });



    mposition4212 = new google.maps.LatLng(40.853300,-73.939603);

    latlngbounds.extend(mposition4212);

    mmarkers[4212] = new google.maps.Marker({
			position: mposition4212,
			map: map
	      });
      
    mmarkers[4212].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4212], 'click', function() {
    getMission(4212);

    });

        var contentString4212 = '<div style="font-size:12px;"><b>Remove old kitchen sink fixture, install new faucet set</b><br />Location: Cabrini Blvd, Manhattan, NY10033<br />Price: $Offers<br />Due: 2 weeks<br />Click for more information.</div>';
    
    infowindows[4212] = new google.maps.InfoWindow({
	content: contentString4212,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4212], 'mouseover', function() {
   showMissionInfoWindow(4212);
    });

    google.maps.event.addListener(mmarkers[4212], 'mouseout', function() {
    closeMissionInfoWindow(4212);
    });



    mposition4219 = new google.maps.LatLng(40.513879,-74.403363);

    latlngbounds.extend(mposition4219);

    mmarkers[4219] = new google.maps.Marker({
			position: mposition4219,
			map: map
	      });
      
    mmarkers[4219].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4219], 'click', function() {
    getMission(4219);

    });

        var contentString4219 = '<div style="font-size:12px;"><b>deliver sub sandwiches</b><br />Location: Plainfield Ave, NJ08817<br />Price: $Offers<br />Due: Wednesday 1:00pm<br />Click for more information.</div>';
    
    infowindows[4219] = new google.maps.InfoWindow({
	content: contentString4219,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4219], 'mouseover', function() {
   showMissionInfoWindow(4219);
    });

    google.maps.event.addListener(mmarkers[4219], 'mouseout', function() {
    closeMissionInfoWindow(4219);
    });



    mposition4220 = new google.maps.LatLng(40.75,-73.99);

    latlngbounds.extend(mposition4220);

    mmarkers[4220] = new google.maps.Marker({
			position: mposition4220,
			map: map
	      });
      
    mmarkers[4220].setIcon("/images/errands/markers/marker_grey.png");
        mmarkers[4220].setVisible(false);
        google.maps.event.addListener(mmarkers[4220], 'click', function() {
    getMission(4220);

    });

        var contentString4220 = '<div style="font-size:12px;"><b>Seo &amp; link building</b><br />Location: Virtual Mission (Online, Phone, etc)<br />Price: $Offers<br />Due: 2 weeks</div>';
    
    infowindows[4220] = new google.maps.InfoWindow({
	content: contentString4220,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4220], 'mouseover', function() {
   showMissionInfoWindow(4220);
    });

    google.maps.event.addListener(mmarkers[4220], 'mouseout', function() {
    closeMissionInfoWindow(4220);
    });



    mposition4225 = new google.maps.LatLng(40.75,-73.99);

    latlngbounds.extend(mposition4225);

    mmarkers[4225] = new google.maps.Marker({
			position: mposition4225,
			map: map
	      });
      
    mmarkers[4225].setIcon("/images/errands/markers/marker_grey.png");
        mmarkers[4225].setVisible(false);
        google.maps.event.addListener(mmarkers[4225], 'click', function() {
    getMission(4225);

    });

        var contentString4225 = '<div style="font-size:12px;"><b>Create 2 illustrations to accompany a short narrative</b><br />Location: Virtual Mission (Online, Phone, etc)<br />Price: $19.99<br />Due: Thursday 11:30pm</div>';
    
    infowindows[4225] = new google.maps.InfoWindow({
	content: contentString4225,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4225], 'mouseover', function() {
   showMissionInfoWindow(4225);
    });

    google.maps.event.addListener(mmarkers[4225], 'mouseout', function() {
    closeMissionInfoWindow(4225);
    });



    mposition4237 = new google.maps.LatLng(40.750211,-73.989503);

    latlngbounds.extend(mposition4237);

    mmarkers[4237] = new google.maps.Marker({
			position: mposition4237,
			map: map
	      });
      
    mmarkers[4237].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4237], 'click', function() {
    getMission(4237);

    });

        var contentString4237 = '<div style="font-size:12px;"><b>Wait in line for iPad2</b><br />Location: W 34th St, Manhattan, NY10001<br />Price: $Offers<br />Due: Today 5:00pm<br />Click for more information.</div>';
    
    infowindows[4237] = new google.maps.InfoWindow({
	content: contentString4237,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4237], 'mouseover', function() {
   showMissionInfoWindow(4237);
    });

    google.maps.event.addListener(mmarkers[4237], 'mouseout', function() {
    closeMissionInfoWindow(4237);
    });



    mposition4239 = new google.maps.LatLng(40.634808,-73.963834);

    latlngbounds.extend(mposition4239);

    mmarkers[4239] = new google.maps.Marker({
			position: mposition4239,
			map: map
	      });
      
    mmarkers[4239].setIcon("/images/errands/markers/marker_grey.png");
        google.maps.event.addListener(mmarkers[4239], 'click', function() {
    getMission(4239);

    });

        var contentString4239 = '<div style="font-size:12px;"><b>Paint My Apartment</b><br />Location: Rugby Rd, Brooklyn, NY11230<br />Price: $Offers<br />Due: 2 weeks<br />Click for more information.</div>';
    
    infowindows[4239] = new google.maps.InfoWindow({
	content: contentString4239,
	maxWidth: 300
    });
    google.maps.event.addListener(mmarkers[4239], 'mouseover', function() {
   showMissionInfoWindow(4239);
    });

    google.maps.event.addListener(mmarkers[4239], 'mouseout', function() {
    closeMissionInfoWindow(4239);
    });



    if(mmarkers.length > 0 && userPositionSet==false) {
	map.fitBounds(latlngbounds);
	 google.maps.event.addListener(map, "bounds_changed", function() {
	  if(map.getZoom()> 11 && userPositionSet==false) {
	    map.setZoom(11);
	  }
	  userPositionSet=true;
	});
    }

}



function setupPage() {

    //$(document).ready(function(){


  document.getElementById('background-layer').style.height = getDocHeight() + "px";

  setupMap();
  setupMissionMarkers();
  setLocation(40.75,-73.99);
  
  
    getLocation(false);
  
}
//});

</script>

<h1><img src="/images/errands/run-a-mission-title.gif" alt="Run a Mission" /></h1>

<div id="error">
There were errors with your request:<ul class="ccm-error"><li>The mission you requested is not currently available</li></ul></div>

<div id="mission-holder">
    <div id="mission-list">
	To view more details about a Mission, just click on its title.<br />
		There are <b>5 virtual missions</b>, they are included in the list below, but not displayed on the map.
		
<br />
<br />
	<div id="header">
	    <!--<div id="pagination"><div class="ccm-spacer"></div><div class="ccm-pagination"><span class="ccm-page-left"><span class="ltgray">&laquo; Previous</span></span><span class="ccm-page-right"><span class=""><a href="/errands/addthis_widget.js?ccm_paging_p=2" >Next &raquo;</a></span></span><span class='currentPage'> <strong>1</strong> </span><span class=''> <a href='/errands/addthis_widget.js?ccm_paging_p=2' >2</a> </span></div></div>!-->
	    <div class="title"><a href="javascript:void(0)" onclick="changeSortOrder('Title','ASC')">Mission Title</a></div>
	    <div class="due"><a href="javascript:void(0)" onclick="changeSortOrder('Due_Date','DESC')">Due</a></div>
	    <div class="runner-pays"><a href="javascript:void(0)" onclick="changeSortOrder('Own_Funds','ASC')">Need $</a> <img src="/images/help-icon.gif" title="This means that you will have to spend some of your own money on this Mission.  Don't worry though, you will be fully reimbursed by the Client." class="tool-tip-icon"></div>
	    <div class="price"><a href="javascript:void(0)" onclick="changeSortOrder('Price','ASC')">Reward</a> <img src="/images/help-icon.gif" title="This is how much you will be paid to accomplish this Mission" class="tool-tip-icon"></div>
	    
	    <br />	    <div id="due-legend"><img src="/images/errands/arrow_down.gif" /></div>	    	    	</div>
			
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/wait-in-line-for-ipad2-1" onClick="getMission(4237,true); return false;" onMouseOver="showMissionInfoWindow(4237)" onMouseOut="closeMissionInfoWindow(4237)">Wait in line for iPad2</a></h3>
		    		    <div class="location">W 34th St, Manhattan, NY10001</div>
		    		</div>
		<div class="due">Today 5:00pm</div>
				<div class="runner-pays">No</div>
						<div class="price">Make an offer</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4237)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">MAKE AN OFFER</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/review-text-in-english-9" onClick="getMission(4201,true); return false;" onMouseOver="showMissionInfoWindow(4201)" onMouseOut="closeMissionInfoWindow(4201)">Edit text on www</a></h3>
		    		    <div class="location">Virtual Mission (Online, Phone, etc)</div>
		    		</div>
		<div class="due">Tuesday 10:00pm</div>
				<div class="runner-pays">No</div>
						<div class="price">$12.00</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4201)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">ACCEPT MISSION</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/deliver-sub-sandwiches-1" onClick="getMission(4219,true); return false;" onMouseOver="showMissionInfoWindow(4219)" onMouseOut="closeMissionInfoWindow(4219)">deliver sub sandwiches</a></h3>
		    		    <div class="location">Plainfield Ave, NJ08817</div>
		    		</div>
		<div class="due">Wednesday 1:00pm</div>
				<div class="runner-pays">Yes</div>
						<div class="price">Make an offer</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4219)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">MAKE AN OFFER</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/just-bring-10-people-to-see-a-new-indie-band" onClick="getMission(4049,true); return false;" onMouseOver="showMissionInfoWindow(4049)" onMouseOut="closeMissionInfoWindow(4049)">Just bring 10 people to see a new indie band!</a></h3>
		    		    <div class="location">Ludlow St, Manhattan, NY10002</div>
		    		</div>
		<div class="due">Wednesday 9:30pm</div>
				<div class="runner-pays">No</div>
						<div class="price">$60.00</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4049)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">ACCEPT MISSION</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/get-paid-to-bring-10-people-to-see-a-new-indie-band" onClick="getMission(4197,true); return false;" onMouseOver="showMissionInfoWindow(4197)" onMouseOut="closeMissionInfoWindow(4197)">Get paid to bring 10 people to see a new indie band!</a></h3>
		    		    <div class="location">Ludlow St, Manhattan, NY10002</div>
		    		</div>
		<div class="due">Wednesday 10:00pm</div>
				<div class="runner-pays">No</div>
						<div class="price">$60.00</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4197)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">ACCEPT MISSION</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/create-2-illustrations-to-accompany-a-short-narrative-1" onClick="getMission(4225,true); return false;" onMouseOver="showMissionInfoWindow(4225)" onMouseOut="closeMissionInfoWindow(4225)">Create 2 illustrations to accompany a short narrative</a></h3>
		    		    <div class="location">Virtual Mission (Online, Phone, etc)</div>
		    		</div>
		<div class="due">Thursday 11:30pm</div>
				<div class="runner-pays">No</div>
						<div class="price">$19.99</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4225)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">ACCEPT MISSION</a>
		    		</div>!-->
	    </div>
		
	    <div class="mission">
		<div class="title">
		    <h3><a href="/errands/need-clients-for-my-daycare-baby-cubs-daycare-inc-3" onClick="getMission(4030,true); return false;" onMouseOver="showMissionInfoWindow(4030)" onMouseOut="closeMissionInfoWindow(4030)">Need Clients for my Daycare (Baby Cubs Daycare, Inc.)</a></h3>
		    		    <div class="location">Virtual Mission (Online, Phone, etc)</div>
		    		</div>
		<div class="due">1 week</div>
				<div class="runner-pays">No</div>
						<div class="price">$100.00</div>
				<!--<div class="buttons"><a href="javascript:void(0);" onClick="getMission(4030)">MORE INFO</a>&nbsp;&nbsp;|&nbsp;&nbsp;
		    		    <a href="">ACCEPT MISSION</a>
		    		</div>!-->
	    </div>
		<BR style="clear:both">
	<div id="mission-list-footer"><div class="ccm-spacer"></div><div class="ccm-pagination"><span class="ccm-page-left"><span class="ltgray">&laquo; Previous</span></span><span class="ccm-page-right"><span class=""><a href="/errands/?&ccm_paging_p=2" >Next &raquo;</a></span></span><span class='currentPage'> <strong>1</strong> </span><span class=''> <a href='/errands/?&ccm_paging_p=2' >2</a> </span></div></div>
	<br />
	<b>Get new Mission notifications</b> via twitter SMS by txting <b>follow @directorgreen</b> to 40404 or by following <a href="http://www.twitter.com/directorgreen" target="_blank">@directorgreen</a> on twitter.
    </div>
    <div id="gmap-holder">
	<div id="location-form">
	    <form id="distance_form" name="distance_form" action="/errands/" method="post">
		To find missions closer to you, please <a href="javascript:void(0);" onclick="getLocation();">click here to find your location</a> or enter your ZIP below.
		<br /><br />
	    Show missions within <select class="ccm-input-select" name="distance" id="distance" ccm-passed-value="0" ><option value="0.00001" >virtual only</option><option value="0.5" >0.5 miles</option><option value="1" >1 mile</option><option value="2" >2 miles</option><option value="3" >3 miles</option><option value="4" >4 miles</option><option value="5" >5 miles</option><option value="7" >7 miles</option><option value="10" >10 miles</option><option value="15" >15 miles</option><option value="20" >20 miles</option><option value="0" selected>any distance</option></select>	    from ZIP <input id="zip" type="text" name="zip" value="10118" style="width:50px; text-align:center;" style="width:50px; text-align:center;" class="ccm-input-text" />
	    <input type="hidden" name="sort_column" id="sort_column" value="Due_Date" />	    <input type="hidden" name="sort_direction" id="sort_direction" value="ASC" />

	    <input type="submit" class="ccm-input-submit " id="submit_update" name="submit_update" value="Update"  />	    </form>
	</div>
	<div id="map_canvas"></div>
	<div id="legend"><img src="/images/errands/legend.png" alt="Map Legend" /></div>
    </div>
</div>
</div>


	
    </div>

        <div id="footer">
            <div class="center"><div class="links"><a href="http://www.facebook.com/pages/New-York-NY/Agent-Anything/156564541026353?v=info" target="_blank"><img src="/images/social-icons/facebook-button.gif" alt="Find us on Facebook" /></a>
	    <a href="http://twitter.com/AgentAnything" target="_blank"><img src="/images/social-icons/twitter-button.gif" alt="Follow us on Twitter" /></a>
	    <div class="verisign">
		<script type="text/javascript" src="https://seal.verisign.com/getseal?host_name=www.agentanything.com&amp;size=S&amp;use_flash=YES&amp;use_transparent=YES&amp;lang=en"></script>
	    </div>

	    <br />
	    <a href="/privacy-policy/">Privacy Policy</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="/terms-of-use/">Terms &amp; Conditions</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="/members/">Members</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
            &copy; Agent Anything Inc. 2011</div></div>
            <div class="left"></div>
            <div class="right"></div>
        </div>

</div>
<div class="background-base" id="background-base"></div>
<script src="https://static.getclicky.com/js" type="text/javascript"></script>

<script type="text/javascript">clicky.init(247553);</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="https://in.getclicky.com/247553ns.gif" /></p></noscript><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18335145-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script type="text/javascript">
adroll_adv_id = "HAEFJQAYAZGX5FTW6UWEEW";
adroll_pix_id = "7XQQN5PJS5B4LI522ZIZBH";
(function () {
var oldonload = window.onload;
window.onload = function(){
   __adroll_loaded=true;
   var scr = document.createElement("script");
   var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
   scr.setAttribute('async', 'true');
   scr.type = "text/javascript";
   scr.src = host + "/j/roundtrip.js";
   document.documentElement.firstChild.appendChild(scr);
   if(oldonload){oldonload()}};
}());
</script><script type="text/javascript">
  var uservoiceOptions = {
    key: 'agentanything',
    host: 'agentanything.uservoice.com',
    forum: '72301',
    alignment: 'right',
    background_color:'#8ad03e',
    text_color: 'white',
    hover_color: '#5a7d14',
    lang: 'en',
    showTab: true
  };
  function _loadUserVoice() {
    var s = document.createElement('script');
    s.src = ("https:" == document.location.protocol ? "https://" : "http://") + "uservoice.com/javascripts/widgets/tab.js";
    document.getElementsByTagName('head')[0].appendChild(s);
  }
  _loadSuper = window.onload;
  window.onload = (typeof window.onload != 'function') ? _loadUserVoice : function() { _loadSuper(); _loadUserVoice(); };

$(document).ready(function(){

$("#location-change a[title]").tooltip({

position: 'bottom center',
   // tweak the position
   offset: [10, 0],

   bounce: true,

   // use the "slide" effect
   effect: 'slide'

// add dynamic plugin with optional configuration for bottom edge
}).dynamic({bottom: {direction: 'down', bounce: true}});


$(".status img[title]").tooltip({

position: 'bottom center',
   // tweak the position
   offset: [10, 0],

   bounce: true,

   // use the "slide" effect
   effect: 'slide'

// add dynamic plugin with optional configuration for bottom edge
}).dynamic({bottom: {direction: 'down', bounce: true}});


});

</script>
<script src="https://static.getclicky.com/js" type="text/javascript"></script>

<script type="text/javascript">clicky.init(247553);</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="https://in.getclicky.com/247553ns.gif" /></p></noscript><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18335145-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script type="text/javascript">
adroll_adv_id = "HAEFJQAYAZGX5FTW6UWEEW";
adroll_pix_id = "7XQQN5PJS5B4LI522ZIZBH";
(function () {
var oldonload = window.onload;
window.onload = function(){
   __adroll_loaded=true;
   var scr = document.createElement("script");
   var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
   scr.setAttribute('async', 'true');
   scr.type = "text/javascript";
   scr.src = host + "/j/roundtrip.js";
   document.documentElement.firstChild.appendChild(scr);
   if(oldonload){oldonload()}};
}());
</script><div id="background-layer"></div>
<div id="user-info-folder" class="folder user-folder">
    <div id="close-user-button" class="folder-close-button"><img src="/images/errands/close_button.png" alt="Close" /></div>

    <div class="main-container">
	<div class="left-container">
	    <div class="paper-top"><img src="/images/errands/folder-paper-top.png" alt="" /></div>
	    <div class="paper-bottom"><img src="/images/errands/folder-paper-bottom.png" alt="" /></div>
	    
	    <div class="avatar">
                <img id="user_info_avatar" src="" alt="User Avatar"/><br />
            </div>

            <div class="user-info">
                <h2 id="username"></h2>
                <span id="userinfo-strapline"></span>
            </div>

            <div id="user-description"></div>

            <div class="user-feedback">
                <h3>Feedback</h3>
                <ul id="feedback-list"></ul>
            </div>

	</div>
	<div class="right-container">

            <div class="mission-statistics">
                <h3>Mission Statistics</h3>
                <div id="pending-box" class="box grey"><span class="statistic" id="pMiss">0</span><br />Pending<br />Missions<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></div>
                <div id="running-box" class="box grey"><span class="statistic" id="rMiss">0</span><br />Running<br />Missions<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></div>
                <div id="accomplished-box" class="box green"><span class="statistic" id="aMiss">0</span><br />Accomplished<br />Missions<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></div>
                <div id="failed-box" class="box red"><span class="statistic" id="fMiss">0</span><br />Failed<br />Missions<span class="lt"></span><span class="rt"></span><span class="lb"></span><span class="rb"></span></div>
            </div>

            <div class="user-rating">
                <div class="user-rating-left"><h3>User Rating</h3>What is the user rating?&nbsp;<img src="/images/help-icon.gif" title="User ratings show how well the User has performed during past missions. The figure is the number of positive feedback ratings minus the number negative ratings." alt="(i)" class="tool-tip-icon" /></div>
                <div class="user-rating-right"><span id="uRate"></span> <img src="" id="uRate_Img" alt="User Rating" /></div>
            </div>

            <div class="user-rating-breakdowns">
                <div class="breakdown-row">
                # Positive Feedbacks:		<span id="posFeedback">0</span>
                </div>
                <hr />
                <div class="breakdown-row">
                # Neutral Feedbacks:		<span id="neuFeedback">0</span>
                </div>
                <hr />
                <div class="breakdown-row">
                # Negative Feedbacks:		<span id="negFeedback">0</span>
                </div>
            </div>

	</div>
    </div>
</div>


<div id="mission-folder" class="folder mission-folder">
    <div id="close-button" class="folder-close-button"><img src="/images/errands/close_button.png" alt="Close" /></div>

    <div id="main-container">
	<div id="left-container">
	    <div id="paper-top"><img src="/images/errands/folder-paper-top.png" alt="Folder Artwork" /></div>
	    <div id="paper-bottom"><img src="/images/errands/folder-paper-bottom.png" alt="Folder Artwork" /></div>
	    <h1 id="mission-title">Mission Title</h1>
	    <br />
	    <div id="mission-description"></div>
	    <br />
	    <div id="mission-private-info">
	    <img src="/images/errands/classified-information-small-title.png" alt="Classified Information" />
	    <br />
	    <span class="dark_grey" id="private-info-text"></span>
	    <br />
	    </div>
            
            <div id="agent-promotion-message"></div>
	    <div id="details-bottom">
		<br />
	    <HR>
	    <br />
	    <span id="own_funds_holder"></span><span id="own_funds_method">The client will re-imburse you on completion.</span>
	    <br />
	    </div>
	    <div id="reward-area">
		<span id="reward-text"><h1><div class="red"><img src="/images/errands/reward-title.png" alt="REWARD:" style="float:left" /></div><div id="mission-price" style="float:left; margin-top:4px; margin-left:10px;">$10.00</div></h1></span>
	    	    	    <div id="offer-form-holder">
		<br />
		<form id="offer-form" name="offer-form" action="">
		    <b class="green">How much would you like to offer <br />to complete this mission?</b><br />
		    $<input id="Offer" type="text" name="Offer" value="10.00" class="ccm-input-text" />		    <input type="hidden" name="rcID" id="rcID" value="" />		</form>
	    </div>
	    <div id="mission-buttons">
		<a href="javascript:void(0)" id="accept-mission"><img src="/images/errands/accept-mission-button.png" alt="Accept Mission" id="accept-mission-button" /></a>
		<a href="javascript:void(0)" id="make-offer" onclick="document.getElementById('offer-form').submit()"><img src="/images/errands/offer-mission-button.png" alt="Make an offer" id="offer-mission-button" /></a>
	    </div>
	    	    	    </div>
	    
	    <div id="qas" class="black">
		<br /><hr><br />
	    <h2>Questions &amp; Answers</h2>
	    <ul id="qas-list"><li>No Questions</li></ul>
	    	    <a href="javascript:void(0)" id="qas-login-link">You must be logged in as an Agent to ask questions.</a>	    <form name="qas-form" id="qas-form" action="" method="post">
		<textarea id="qas-question"></textarea>
		<input type="button" value="Ask Question" name="submit" id="qas-button" onclick="f.submitAskQuestion();" /><img src="/images/errands/post/check_load.gif" alt="Loading" id="qas-loading" />
	    </form>
	    <span id="qas-success" class="green">Thanks, your question has been sent to the Client, we'll let you know as soon as we receive a reponse.</span>
	    <span id="qas-failed" class="red">Your question could not be submited, <a href="javascript:void(0);" onclick="f.setupQuestions()">click here to try again</a>.</span>
	    </div>

            
	</div>
	<div id="right-container">


	    <div id="mission-details">

    <div id="avatar">
	<img id="user_avatar" src="" alt="Client Avatar"/><br />
    </div>
    <div id="info">
	<span class="green bold">Client: </span><span id="poster_display_name"></span><br />
	<span class="green bold">Due By: </span><span id="due_date"></span><br />
	<span class="green bold">Accept By: </span><span id="accepting_date"></span><br />
	            <div id="flag-mission"><img src="/images/flag-red-icon.png" title="Clicking this link will take you to a form which will allow you to notify us that you think there is something wrong with this Mission." alt="(i)" class="tool-tip-icon" /> <a href="" id="flag-link">Flag this mission for review by us.</a></div>
            	<span id="mission-links"></span>
	<br />
    </div>
    
		
	    </div>

	    <BR style="clear:both;">
	    <hr>
	    <div id="mission-locations">
	    <h2>Mission Location</h2>
	    <ol id="locations-list">
	    </ol>
	    </div>
	  <div id="mission-map"></div>

	</div>
    </div>
</div>

    <div class="addthis_toolbox atfixed" id="add_this_toolbox">
	<div class="custom_images">
	    <a class="addthis_button_facebook"><img src="/images/social-icons/facebook32.png" alt="Share to Facebook" /></a>
	    <a class="addthis_button_twitter"><img src="/images/social-icons/twitter32.png"  alt="Share to Twitter" /></a>
	    <a class="addthis_button_stumbleupon"><img src="/images/social-icons/stumbleupon32.png" alt="Stumble It" /></a>
	    <a class="addthis_button_more"><img src="/images/social-icons/addthis32.png" alt="More..." /></a>
	</div>
    </div></body>
</html>