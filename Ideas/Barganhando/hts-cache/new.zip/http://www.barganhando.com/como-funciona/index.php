<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br" xmlns:og="http://ogp.me/ns#"
      xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="resource-type" content="document" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="revisit-after" content="1" />
<meta name="description" content="bom mesmo é barganhar"/>
<meta name="keywords" content="compras coletivas, compras, comprar produtos" />
<meta name="robots" content="all"/>
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="author" content="Gorila Comunicação Web" />
<meta name="language" content="pt-br" />



<link rel="shortcut icon" type="image/x-icon" href="http://www.barganhando.com/global/images/favicon.ico" />

<title>Barganhando - bom mesmo é barganhar</title>

<link href="http://www.barganhando.com/global/css/style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/validacao.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/jalert.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://www.barganhando.com/global/js/jquery-1.4.2.js"></script> 
<!--<script type="text/javascript" src="global/js/jquery-1.4.4.min.js"></script>-->
<!--cufon-->
<script src="http://www.barganhando.com/global/js/cufon/cufon-yui.js" type="text/javascript"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/cufon/funcao.js"></script>
<script src="http://www.barganhando.com/global/js/cufon/The_Mix_Bold-_700.font.js" type="text/javascript"></script>

<!--alert-->
<script src="http://www.barganhando.com/global/js/jAlert/alerts.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaRecebe.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaConvidar.js"></script>

<!--limpa campos--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/clear.js"></script>
<!--interação no browser-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/fav.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/pagInicial.js"></script>

<!--para descrição da empresa logo abaixo da oferta--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/descEmpresa.js"></script>
<!--faz a div logar aparecer--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/logar.js"></script>

<!--para os selects--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/jqtransform/jquery.jqtransform.js" ></script>
<link href="http://www.barganhando.com/global/js/jqtransform/select_cidade.css" rel="stylesheet" type="text/css" media="screen" />


<script type="text/javascript">
		$(function(){
			$('#escolha-cid').jqTransform({imgPath:'http://www.barganhando.com/global/js/jqtransform/img/'});
			});
	</script>


<!--[if IE 7]>
<link href="http://www.barganhando.com/global/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if IE]>
<link href="http://www.barganhando.com/global/css/ie.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if gte IE 9]>
	<script type="text/javascript">
		Cufon.set('engine', 'canvas');
	</script>
<![endif]-->


<!--demais js functions-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/scripts.js"></script>


<!--tooltip-->

<script type="text/javascript" src="http://www.barganhando.com/global/js/tooltip/vtip.js"></script>
<link rel="stylesheet" type="text/css" href="http://www.barganhando.com/global/js/tooltip/vtip.css" />

<script type="text/javascript"> 
 
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 
</script><link href="../global/css/como-funciona.css" rel="stylesheet" type="text/css" media="screen" />
</head><body>
<div id="topo">
  <div id="sombrasTopo">
    <div id="contTopo">
      <h1><a href="http://www.barganhando.com/" title="Página Principal">Barganhando - as melhores empresas com os melhores descontos</a></h1>
      <div id="cidades" class="brasilia">
        <div class="escolhas"> <span class="asMelhores">As melhores ofertas de</span>
          <form name="escolha-cid" id="escolha-cid">
            <fieldset>
            
              
              <select name="cidades" id="cids" onchange="MM_jumpMenu('parent',this,0)">
                <option value="http://www.barganhando.com/index.php?cid=Brasilia" selected>Brasilia</option>
                              </select>
    
            </fieldset>
          </form>
        </div>
      </div>
      <div id="cadastroBrowser">
        <form action="http://www.barganhando.com/cadastrar/act.php?c=2" name="recebaOfertas" id="recebaOfertas" method="post" onSubmit="return validaRecebe(this)">
          <fieldset>
            <ul>
              <li>
                <label for="cid">Receba ofertas de Brasilia por email:</label>
              </li>
              <li> <span class="campo">
                <input type="text" name="email_usuario" id="email_usuario" value="DIGITE AQUI SEU EMAIL" onfocus="limpar(this);" onblur="escrever(this);" />
                <input type="hidden" name="cod_cidade" value="2" />
                </span> </li>
              <li>
                <button type="submit" name="cadastrar" id="cadastrar">cadastre-se</button>
                 </li>
            </ul>
          </fieldset>
        </form>
        <div class="clear"></div>
        <ul class="browser">
          <li class="home"><a href="#" class="home" onclick="setHomepage();">Coloque o Barganhando como página inicial</a></li>
          <li class="fav"><a href="http://barganhando.com" class="favoritos" title="Barganhando - as melhores empresas com os melhores descontos">Coloque o Barganhando nos Favoritos</a></li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
    <div id="menu-login">
      <ul id="menu">
        <li><a href="http://www.barganhando.com/" >Oferta do dia</a></li>
        <li><a href="http://www.barganhando.com/ofertas-recentes/" >Ofertas Recentes</a></li>
        <li><a href="http://www.barganhando.com/seguranca/" >Segurança</a></li>
        <li><a href="http://www.barganhando.com/como-funciona/" class="ativo">Como Funciona</a></li>
        <li><a href="http://www.barganhando.com/faq/" >Perguntas Frequentes</a></li>
      </ul>
      <div id="log">
        <ul id="login">
          <li class="login"><a href="#" id="vLogar">Login</a></li>
          <li class="conta"><a href="http://www.barganhando.com/cadastrar/">Crie uma conta</a></li>
        </ul> 
      </div>
    </div>
  </div>
</div><div id="wrap">
  <div id="inner">
    <div id="logar" style="display:none">
      <div id="innerLogar">
        <h2>Faça o login</h2>
        <form action="http://www.barganhando.com/act.php?l=1" name="formLogar" id="formLogar" method="post">
          <fieldset>
            <ul>
              <li class="campos">
                <label for="emailLogar"> Email:</label>
                <span class="ipt nome">
                <!--  value="DIGITE SEU EMAIL" -->
                <input type="text" name="email" id="emailLogar" class="validate[required,length[0,255],]" onfocus="limpar(this);" onBlur="escrever(this);" />
                </span> </li>
              <li>
                <label for="senha"> Senha:</label>
                <span class="ipt">
                <input type="password" name="senha" id="senha" class="validate[required,length[0,255],]" />
                </span> <span class="txts">Esqueceu sua senha? <a href="http://www.barganhando.com/login/">Clique aqui</a></span> </li>
                <input type="hidden" name="place" value="/como-funciona/index.php" />
              <li> 
                <button type="submit" name="facaLogin" id="facaLogin">faça o login</button>
              </li>
            </ul>
          </fieldset>
        </form>
        <div id="infoCadastrar">
          <h3>Ainda não é cadastrado?</h3>
          <p>Não perca tempo! Cadastre-se agora para aproveitar as melhores ofertas das melhores empresas da sua cidade.</p>
          <a href="http://www.barganhando.com/cadastrar/" class="lkn-cadastrar">Cadastrar</a> </div>
      </div>
      <a href="javascript:;" class="lkn-fechar">fechar</a> </div>    <div id="conteudo">
      <div class="paginas">
        <h2>COMO FUNCIONA</h2>
        <ul class="lista-comoFunciona">
          <li><div class="caixa-um"> <span class="imgs"> <img src="../global/images/icoComoFunciona01.png" alt="1º Passo" /> </span><span class="txt-direita txt-um">Todas as vezes que você acessar o Barganhando.com, encontrará um super desconto em algum produto ou serviço da sua cidade. 
Sabe aquele almoço que você adora ou aquela massagem que você tanto precisa? Aqui você encontra pela metade do preço. Ou melhor, até 90% mais barato!
Aproveite o Barganhando.com para aproveitar tudo aquilo que você já gosta e para conhecer coisas novas na sua cidade.
Para comprar, basta fazer o seu cadastro no site. É simples e grátis.
</span> </div></li>
          <li> <div class="caixa-dois"><span class="imgs"> <img src="../global/images/icoComoFunciona02.png" alt="2º Passo" /> </span><span class="txt-dois">Existem várias maneiras de ficar antenado no Barganhando.com para não perder nenhuma oferta. Você pode se cadastrar no site para receber nossos e-mails diários de descontos ou seguir-nos e interagir conosco nas principais redes sociais – Facebook, Twitter e Orkut.
Lembre-se: os nossos descontos precisam de um número mínimo de compradores. Portanto, quanto mais você divulgar as ofertas, maiores as chances se dar bem. Além disso, você pode indicar o site para seus amigos. Se eles comprarem, você ganha R$ 10,00 em créditos para compras no site.
</span></div> </li>
          <li><div class="caixa-tres"> <span class="imgs"> <img src="../global/images/icoComoFunciona03.png" alt="3º Passo" /> </span><span class="txt-direita txt-tres">Após comprar no Barganhando.com com total segurança, nós disponibilizaremos um cupom com um código exclusivo na sua área personalizada do site. Basta imprimí-lo e levá-lo até o estabelecimento para usufruir de um super produto ou serviço com um super desconto. A sensação é ótima, experimente!</span> </div></li>
        </ul>
      </div>
    </div>
     <div class="clear"></div>
    <div id="rodape"> <a href="http://www.barganhando.com" title="Barganhando.com" class="logoRodape">Barganhando - as melhores empresas com os melhores descontos</a>
      <ul class="lkn-rodape barganhando">
        <li>
          <h3>Barganhando.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/conheca/">Conheça</a></li>
        <li class="item"><a href="http://www.barganhando.com/termos-de-uso/">Termos de Uso</a></li>
        <li class="item"><a href="http://www.barganhando.com/contato/">Contato</a></li>
        <li class="item"><a href="http://www.barganhando.com/faq/">Perguntas Frequentes</a></li>
        <li class="item"><a href="http://www.barganhando.com/seja-nosso-parceiro/">Seja nosso parceiro</a></li>
      </ul>
      <ul class="lkn-rodape sugestoes">
        <li>
          <h3>Sugira.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/sugira/">uma cidade</a></li>
        <li class="item"><a href="http://www.barganhando.com/sugira-oferta/">uma oferta</a></li>
      </ul>
      <ul class="lkn-rodape forma-pagamento">
        <li>
          <h3>Forma de Pagamento</h3> <ul>
               <li class="rede-pagt pagseguro"><a href="http://pagseguro.com.br" target="_blank">pagseguro uol</a></li>
        </ul>
        </li>
       
      </ul>
      <div class="clear"></div>
      <div class="copyright">
        <p style="float:left; width:940px;">&copy; 2011 Barganhando.com. Todos os direitos reservados</p>
        
        
        <a href="http://gori.la" title="Gori.la Comunicação Web" class="logoAgencia" target="_blank">Gori.la - Comunicação Web</a>
        
        
        
      </div>
    </div>
  </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script type="text/javascript">
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);

(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>
