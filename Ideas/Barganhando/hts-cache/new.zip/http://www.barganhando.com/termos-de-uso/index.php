<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br" xmlns:og="http://ogp.me/ns#"
      xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="resource-type" content="document" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="revisit-after" content="1" />
<meta name="description" content="bom mesmo é barganhar"/>
<meta name="keywords" content="compras coletivas, compras, comprar produtos" />
<meta name="robots" content="all"/>
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="author" content="Gorila Comunicação Web" />
<meta name="language" content="pt-br" />



<link rel="shortcut icon" type="image/x-icon" href="http://www.barganhando.com/global/images/favicon.ico" />

<title>Barganhando - bom mesmo é barganhar</title>

<link href="http://www.barganhando.com/global/css/style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/validacao.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/jalert.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://www.barganhando.com/global/js/jquery-1.4.2.js"></script> 
<!--<script type="text/javascript" src="global/js/jquery-1.4.4.min.js"></script>-->
<!--cufon-->
<script src="http://www.barganhando.com/global/js/cufon/cufon-yui.js" type="text/javascript"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/cufon/funcao.js"></script>
<script src="http://www.barganhando.com/global/js/cufon/The_Mix_Bold-_700.font.js" type="text/javascript"></script>

<!--alert-->
<script src="http://www.barganhando.com/global/js/jAlert/alerts.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaRecebe.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaConvidar.js"></script>

<!--limpa campos--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/clear.js"></script>
<!--interação no browser-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/fav.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/pagInicial.js"></script>

<!--para descrição da empresa logo abaixo da oferta--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/descEmpresa.js"></script>
<!--faz a div logar aparecer--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/logar.js"></script>

<!--para os selects--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/jqtransform/jquery.jqtransform.js" ></script>
<link href="http://www.barganhando.com/global/js/jqtransform/select_cidade.css" rel="stylesheet" type="text/css" media="screen" />


<script type="text/javascript">
		$(function(){
			$('#escolha-cid').jqTransform({imgPath:'http://www.barganhando.com/global/js/jqtransform/img/'});
			});
	</script>


<!--[if IE 7]>
<link href="http://www.barganhando.com/global/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if IE]>
<link href="http://www.barganhando.com/global/css/ie.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if gte IE 9]>
	<script type="text/javascript">
		Cufon.set('engine', 'canvas');
	</script>
<![endif]-->


<!--demais js functions-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/scripts.js"></script>


<!--tooltip-->

<script type="text/javascript" src="http://www.barganhando.com/global/js/tooltip/vtip.js"></script>
<link rel="stylesheet" type="text/css" href="http://www.barganhando.com/global/js/tooltip/vtip.css" />

<script type="text/javascript"> 
 
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 
</script><link href="../global/css/ofertas-antigas.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<div id="topo">
  <div id="sombrasTopo">
    <div id="contTopo">
      <h1><a href="http://www.barganhando.com/" title="Página Principal">Barganhando - as melhores empresas com os melhores descontos</a></h1>
      <div id="cidades" class="brasilia">
        <div class="escolhas"> <span class="asMelhores">As melhores ofertas de</span>
          <form name="escolha-cid" id="escolha-cid">
            <fieldset>
            
              
              <select name="cidades" id="cids" onchange="MM_jumpMenu('parent',this,0)">
                <option value="http://www.barganhando.com/index.php?cid=Brasilia" selected>Brasilia</option>
                              </select>
    
            </fieldset>
          </form>
        </div>
      </div>
      <div id="cadastroBrowser">
        <form action="http://www.barganhando.com/cadastrar/act.php?c=2" name="recebaOfertas" id="recebaOfertas" method="post" onSubmit="return validaRecebe(this)">
          <fieldset>
            <ul>
              <li>
                <label for="cid">Receba ofertas de Brasilia por email:</label>
              </li>
              <li> <span class="campo">
                <input type="text" name="email_usuario" id="email_usuario" value="DIGITE AQUI SEU EMAIL" onfocus="limpar(this);" onblur="escrever(this);" />
                <input type="hidden" name="cod_cidade" value="2" />
                </span> </li>
              <li>
                <button type="submit" name="cadastrar" id="cadastrar">cadastre-se</button>
                 </li>
            </ul>
          </fieldset>
        </form>
        <div class="clear"></div>
        <ul class="browser">
          <li class="home"><a href="#" class="home" onclick="setHomepage();">Coloque o Barganhando como página inicial</a></li>
          <li class="fav"><a href="http://barganhando.com" class="favoritos" title="Barganhando - as melhores empresas com os melhores descontos">Coloque o Barganhando nos Favoritos</a></li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
    <div id="menu-login">
      <ul id="menu">
        <li><a href="http://www.barganhando.com/" >Oferta do dia</a></li>
        <li><a href="http://www.barganhando.com/ofertas-recentes/" >Ofertas Recentes</a></li>
        <li><a href="http://www.barganhando.com/seguranca/" >Segurança</a></li>
        <li><a href="http://www.barganhando.com/como-funciona/" >Como Funciona</a></li>
        <li><a href="http://www.barganhando.com/faq/" >Perguntas Frequentes</a></li>
      </ul>
      <div id="log">
        <ul id="login">
          <li class="login"><a href="#" id="vLogar">Login</a></li>
          <li class="conta"><a href="http://www.barganhando.com/cadastrar/">Crie uma conta</a></li>
        </ul> 
      </div>
    </div>
  </div>
</div><div id="wrap">
  <div id="inner">
    <div id="logar" style="display:none">
      <div id="innerLogar">
        <h2>Faça o login</h2>
        <form action="http://www.barganhando.com/act.php?l=1" name="formLogar" id="formLogar" method="post">
          <fieldset>
            <ul>
              <li class="campos">
                <label for="emailLogar"> Email:</label>
                <span class="ipt nome">
                <!--  value="DIGITE SEU EMAIL" -->
                <input type="text" name="email" id="emailLogar" class="validate[required,length[0,255],]" onfocus="limpar(this);" onBlur="escrever(this);" />
                </span> </li>
              <li>
                <label for="senha"> Senha:</label>
                <span class="ipt">
                <input type="password" name="senha" id="senha" class="validate[required,length[0,255],]" />
                </span> <span class="txts">Esqueceu sua senha? <a href="http://www.barganhando.com/login/">Clique aqui</a></span> </li>
                <input type="hidden" name="place" value="/termos-de-uso/index.php" />
              <li> 
                <button type="submit" name="facaLogin" id="facaLogin">faça o login</button>
              </li>
            </ul>
          </fieldset>
        </form>
        <div id="infoCadastrar">
          <h3>Ainda não é cadastrado?</h3>
          <p>Não perca tempo! Cadastre-se agora para aproveitar as melhores ofertas das melhores empresas da sua cidade.</p>
          <a href="http://www.barganhando.com/cadastrar/" class="lkn-cadastrar">Cadastrar</a> </div>
      </div>
      <a href="javascript:;" class="lkn-fechar">fechar</a> </div>    <div id="conteudo">
      <div class="paginas">
        <h2>TERMOS DE USO</h2><p align="center"><strong>Condições Gerais do Website  Barganhando.com</strong></p><p>
  Os serviços prestados  por Barganhando Comércio e Comunicação LTDA., empresa inscrita no CNPJ MF sob o  número 13.102.779/0001-06, site hospedado sob o domínio <a href="http://www.barganhando.com">http://www.barganhando.com</a>, doravante identificada apenas como  Barganhando.com, serão disciplinados por estas condições gerais.<br />
  A prévia leitura,  compreensão e aceitação de todas estas disposições é fundamental para os  usuários, pois é indispensável que os mesmos aceitem, sem restrições, as  condições gerais; bem como as políticas e princípos que as norteiam a ação do  Barganhando.com.</p>
<ol type="1">
  <li><strong>Objeto</strong></li>
  	<ol  type="a">
    	<li>As  condições gerais aqui previstas são aplicáveis à realização, pelo  Barganhando.com, de ofertas periódicas para aquisição, mediante compra coletiva  pelos usuários cadastrados, com descontos, de produtos/serviços de empresas  parceiras do Barganhando.com, tudo condicionado ao atingimento de um número  mínimo de aquisições, pré estabelecido e divulgado.</li>

    	<li >Atingido  ou superado o número mínimo de aquisições pré estabelecido, dar-se-á a  validação da oferta. Após o que, o usuário receberá o produto adquirido  diretamente do parceiro, mediante a apresentação de um cupom que contém um  código único, gerado pelo Barganhando.com e disponibilizado na sessão de “Meus  Cupons” do site.</li>

    	<li>O usuário  adquirente de quaisquer dos produtos/serviços com ofertas disponibilizadas  através do site adquire diretamente do parceiro, sem a garantia ou  responsabilidade por parte do Barganhando.com pela qualidade, entrega,  quantidade, estado e manutenção do que foi adquirido.</li>

	    <li>Estas  condições gerais poderão sofrer alterações periódicas e os usuários, desde já,  concordam e reconhecem que é da sua exclusiva e integral responsabilidade, a  verificação dos seus termos.</li>
  	</ol>

  <li><strong>Modelo de Venda</strong></li>


  <ol type="a">
    <li> A aquisição dos produtos ofertados por parte  dos usuários regularmente cadastrados será, feita única e exclusivamente,  através do site <a href="http://www.barganhando.com">www.barganhando.com</a>, dentro do prazo da oferta, antes do seu  esgotamento, mediante a feitura do pagamento nas condições previstas pelo  website.</li>
 
    <li>A oferta  feita pelo Barganhando.com só será validada quando houver o atingimento ou  superação do número mínimo de vendas pré estabelecido e divulgado no website especificamente  para cada produto/serviço.  Caso  contrário, as aquisições ficam resolvidas e os usuários reembolsados no exato  valor do pagamento realizado.</li>

    <li>Dar-se-á o  encerramento da oferta com o atingimento do número máximo de aquisições pré  estabelecido. </li>

    <li>Sendo a  oferta válida, o cupom eletrônico numerado para identificação do adquirente  será disponibilizado para impressão, contendo as condições de uso/entrega  divulgadas pelo website de forma a que os produtos/serviços sejam recebidos do  parceiro.</li>
 
    <li>As ofertas  são realizadas em nome do parceiro, que detém a posse e propriedade dos  produtos/serviços ofertados pelo Barganhando.com, que não integra a cadeia de consumo  ou fornecimento do bem ou serviço adquirido, sendo responsável pela criação,  manutenção e administração dos grupos de compras para cada oferta negociada com  seus parceiros.</li>
  
    <li>O  Barganhando.com não se responsabiliza pelas obrigações tributárias incidentes  sobre as atividades dos usuários/parceiros. </li>
  
    <li>O  Barganhando.com tomará todas as medidas para manter o sigilo e segurança das  informações armazenadas. Contudo, não se responsabiliza por prejuízos  decorrentes de eventuais vazamentos gerados pela intervenção de terceiros.</li>
 
    <li>A  indicação do site barganhando.com feita por usuários dará direito a créditos de  dez reais para compras no site àquele que indicou através do link único,  disponibilizado pelo website. Os créditos serão computados na conta somente  após o indicado ter se cadastrado e realizado e finalizado uma compra no  website.</li>
  
    <li>A validade  dos créditos no site é de 06 (seis) meses a partir da data da sua obtenção.  Será obrigatória a utilização dos créditos nas compras subsequentes à geração  do crédito até o limite definido, caso a caso, pelo website.</li>
 
</ol>
  <li><strong>Cadastramento no Website</strong></li>


  <ol type="a">
    <li>Somente  pode ser usuário do Barganhando.com as pessoas que tenham capacidade legal para  contratar. Não pode utilizar os serviços os menores ou aqueles que tenham sido  inabilitados, temporária ou definitivamente, pelo website.</li>


    <li>É vedado a  uma mesma pessoa ter mais de um cadastro. Tal prática gerará a inabilitação  definitiva.</li>
 
    <li>Pessoas  jurídicas poderão cadastrar-se na figura de seu representante legal,  respeitadas as disposições destas condições gerais.</li>
 
    <li>O usuário  terá o seu cadastramento confirmado após o preenchimento de todos os campos com  informações exatas e verdadeiras.</li>
    <li>O usuário  é o único responsável pela atualização dos seus dados pessoais constantes do  cadastro.</li>
  </ol>
  <li><strong>Sanções</strong></li>

 <ol type="a">
    <li>O  desrespeito por parte de qualquer usuário à legislação e aos termos destas  condições gerais ocasionará sanções, sem prejuízo da responsabilização civil e  criminal pelos atos e omissões.</li>
     <li>O  Barganhando.com se reserva o direito de, unilateralmente, aos seu critério,  notificar, suspender e/ou cancelar o cadastro de usuário, a qualquer tempo, em  caráter definitivo ou temporário, nas hipóteses a seguir:</li>
   
    	 <ol type="i">
      <li>Descumprimento  de quaisquer obrigação ou disposição previstas nestas condições gerais.</li>
      <li>Duplicidade  de cadastro do usuário.</li>
      <li>Constatação  de fraude.</li>
      <li>Verificação  de incorreção nas informações prestadas.</li>
      <li>Recusa de  prestar informações adicionais solicitadas pelo website; e</li>
      <li>Outras  hipóteses que o website considere bastante grave.</li>
    </ol>
  </ol>

  <li><strong>Pagamento</strong></li>

  <ol type="a">
    <li>O  pagamento das ofertas será feito diretamente à empresa designada, especializada  em gestão de pagamentos.</li>
 
    <li>O  Barganhando.com não se responsabiliza pelos serviços prestados pela empresa  contratada para gestão dos pagamentos.</li>
  </ol>

  <li><strong>Propriedade Intelectual</strong></li>



  <ol type="a">
    <li>É  terminantemente vedado o uso comercial do nome empresarial Barganhando.com, bem  como de qualquer conteúdo, inclusive arquivos, do website por pessoas não  autorizadas expressamente.</li>
 
    <li>O  Barganhando.com não se responsabiliza pelo conteúdo, práticas ou serviços de  outros sites, ainda que disponibilize links de acesso para os mesmos.</li>
  </ol>

  <li><strong>Foro</strong></li>


  <ol type="a">
    <li>Fica  eleito para dirimir qualquer questionamento judicial do disposto nestas  condições gerais o foro de Brasília, DF, com a renúncia de qualquer outro por  mais especial que possa ser.</li>
  </ol>
</ol>
      </div>
    </div>
     <div class="clear"></div>
    <div id="rodape"> <a href="http://www.barganhando.com" title="Barganhando.com" class="logoRodape">Barganhando - as melhores empresas com os melhores descontos</a>
      <ul class="lkn-rodape barganhando">
        <li>
          <h3>Barganhando.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/conheca/">Conheça</a></li>
        <li class="item"><a href="http://www.barganhando.com/termos-de-uso/">Termos de Uso</a></li>
        <li class="item"><a href="http://www.barganhando.com/contato/">Contato</a></li>
        <li class="item"><a href="http://www.barganhando.com/faq/">Perguntas Frequentes</a></li>
        <li class="item"><a href="http://www.barganhando.com/seja-nosso-parceiro/">Seja nosso parceiro</a></li>
      </ul>
      <ul class="lkn-rodape sugestoes">
        <li>
          <h3>Sugira.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/sugira/">uma cidade</a></li>
        <li class="item"><a href="http://www.barganhando.com/sugira-oferta/">uma oferta</a></li>
      </ul>
      <ul class="lkn-rodape forma-pagamento">
        <li>
          <h3>Forma de Pagamento</h3> <ul>
               <li class="rede-pagt pagseguro"><a href="http://pagseguro.com.br" target="_blank">pagseguro uol</a></li>
        </ul>
        </li>
       
      </ul>
      <div class="clear"></div>
      <div class="copyright">
        <p style="float:left; width:940px;">&copy; 2011 Barganhando.com. Todos os direitos reservados</p>
        
        
        <a href="http://gori.la" title="Gori.la Comunicação Web" class="logoAgencia" target="_blank">Gori.la - Comunicação Web</a>
        
        
        
      </div>
    </div>
  </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script type="text/javascript">
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);

(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>
