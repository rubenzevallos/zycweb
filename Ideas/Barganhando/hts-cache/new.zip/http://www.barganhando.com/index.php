




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br" xmlns:og="http://ogp.me/ns#"
      xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="resource-type" content="document" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="revisit-after" content="1" />
<meta name="description" content="bom mesmo é barganhar"/>
<meta name="keywords" content="compras coletivas, compras, comprar produtos" />
<meta name="robots" content="all"/>
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="author" content="Gorila Comunicação Web" />
<meta name="language" content="pt-br" />



<link rel="shortcut icon" type="image/x-icon" href="http://www.barganhando.com/global/images/favicon.ico" />

<title>Barganhando - bom mesmo é barganhar</title>

<link href="http://www.barganhando.com/global/css/style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/validacao.css" rel="stylesheet" type="text/css" media="screen" />
<link href="http://www.barganhando.com/global/css/jalert.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://www.barganhando.com/global/js/jquery-1.4.2.js"></script> 
<!--<script type="text/javascript" src="global/js/jquery-1.4.4.min.js"></script>-->
<!--cufon-->
<script src="http://www.barganhando.com/global/js/cufon/cufon-yui.js" type="text/javascript"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/cufon/funcao.js"></script>
<script src="http://www.barganhando.com/global/js/cufon/The_Mix_Bold-_700.font.js" type="text/javascript"></script>

<!--alert-->
<script src="http://www.barganhando.com/global/js/jAlert/alerts.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaRecebe.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/jAlert/ValidaConvidar.js"></script>

<!--limpa campos--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/clear.js"></script>
<!--interação no browser-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/fav.js"></script>
<script type="text/javascript" src="http://www.barganhando.com/global/js/pagInicial.js"></script>

<!--para descrição da empresa logo abaixo da oferta--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/descEmpresa.js"></script>
<!--faz a div logar aparecer--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/logar.js"></script>

<!--para os selects--->
<script type="text/javascript" src="http://www.barganhando.com/global/js/jqtransform/jquery.jqtransform.js" ></script>
<link href="http://www.barganhando.com/global/js/jqtransform/select_cidade.css" rel="stylesheet" type="text/css" media="screen" />


<script type="text/javascript">
		$(function(){
			$('#escolha-cid').jqTransform({imgPath:'http://www.barganhando.com/global/js/jqtransform/img/'});
			});
	</script>


<!--[if IE 7]>
<link href="http://www.barganhando.com/global/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if IE]>
<link href="http://www.barganhando.com/global/css/ie.css" rel="stylesheet" type="text/css" media="screen" />

<![endif]-->


<!--[if gte IE 9]>
	<script type="text/javascript">
		Cufon.set('engine', 'canvas');
	</script>
<![endif]-->


<!--demais js functions-->
<script type="text/javascript" src="http://www.barganhando.com/global/js/scripts.js"></script>


<!--tooltip-->

<script type="text/javascript" src="http://www.barganhando.com/global/js/tooltip/vtip.js"></script>
<link rel="stylesheet" type="text/css" href="http://www.barganhando.com/global/js/tooltip/vtip.css" />

<script type="text/javascript"> 
 
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 
</script><meta http-equiv="Cache-Control" content="no-cache, no-store" />
<meta http-equiv="Pragma" content="no-cache, no-store" />
<meta http-equiv="expires" content="Mon, 06 Jan 1990 00:00:01 GMT" />
<link href="global/css/countdown.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="global/js/jquery.countdown.js"></script>
<script type="text/javascript" src="global/js/jquery.countdown-pt-BR.js"></script>

<!--lightbox-->

<link href="global/js/lightbox/lightbox.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="global/js/lightbox/lightbox.js"></script>
<script type="text/javascript" src="global/js/lightbox/funcao.js"></script>

<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<meta property="og:title" content="50% OFF em Tulipa de Frango ao Molho Rosé acompanhada de Cebola Tirolesa + 2 Chopps + Entrada gratuita no Chá da Boa Cervejaria. Aproveite um delicioso happy hour pela metade do preço"/>
<meta property="og:type" content="company"/>
<meta property="og:url" content="http://barganhando.com/?c=64"/>
<meta property="og:image" content="http://barganhando.com/files/imgs/thumb_950f1e18518275856aec2f176a78e4fe.jpg"/>
<meta property="og:site_name" content="Barganhando.com"/>
<meta property="fb:admins" content="173717062672332"/>
<meta property="og:description" content="50% OFF em Tulipa de Frango ao Molho Rosé acompanhada de Cebola Tirolesa + 2 Chopps + Entrada gratuita no Chá da Boa Cervejaria. Aproveite um delicioso happy hour pela metade do preço"/>
<script type="text/javascript">
$(function () {
   
$(document).ready(function(){
 setInterval(function(){
	$.post('global/incs/timer.php', { date : '2011-03-02 23:59:59' }, function(data) {
	  $('#tempoOferta').html(data);
	});
 }, 1024);
});
	   
 var mapInit = false; //para saber se já carregou
 //$('#map_canvas').hide();
 $('#btn_localizacao').click(function() {
  //$('#map_canvas').fadeToggle();
  if(!mapInit){
   initialize(); //Inicia o gmaps 
   mapInit = true;
  }
 });
});
</script>
<script src="global/js/mapa.js"></script>
<script src="http://www.barganhando.com/global/js/tela_inicio.js"></script>
<script type="text/javascript">
		$(function(){
			$('#cadastroInicio').jqTransform({imgPath:'http://www.barganhando.com/global/js/jqtransform/img/'});
			$('#sugiraInicio').jqTransform({imgPath:'http://www.barganhando.com/global/js/jqtransform/img/'});			
		});
	</script>
<link href="global/css/inicio.css" type="text/css" rel="stylesheet" media="screen" />
</head><body>

<div id="overlayt">&nbsp;</div>
<div id="conteudoInicio">
  <div id="corpoInicio"> <a href="http://www.barganhando.com/?ok=1" class="btnFechar">Fechar</a>
    <div id="topInicio"></div>
    <div id="meioInicio">
      <div class="txt">
        <h3>Seja bem-vindo ao Barganhando.com</h3>
        <form action="http://www.barganhando.com/cadastrar/act.php?c=2" method="post"  name="cadastroInicio" id="cadastroInicio" onSubmit="return validaRecebe(this)">
          <fieldset>
            <p>
              <input type="text" name="email_usuario" id="email_usuario" value="DIGITE AQUI SEU EMAIL" onFocus="limpar(this);" onBlur="escrever(this);" />
            </p>
            <p>
              <select id="cod_cidade" name="cod_cidade">
                <option value="">Selecione uma cidade</option>
                <option value="2">Brasilia</option>
              </select>
              <button type="submit" name="ok" id="ok">Ok</button>
            </p>
          </fieldset>
        </form>
        <p class="sem-cidade">O barganhando.com ainda não chegou à sua cidade?</p>
      </div>
      <ul class="lkns">
        <li><a href="javascript:;" class="sugira" title="Sugira uma cidade para o Barganhando.com">Sugira uma cidade</a></li>
        <li><a href="http://www.barganhando.com/?ok=1" class="cadastrado" title="Já sou cadastrado">já me cadastrei. Desejo ir para o site</a></li>
      </ul>
      <div class="clear"></div>
      <form action="http://www.barganhando.com/sugira/act.php" method="post"  name="sugiraInicio" id="sugiraInicio" style="display:none;">
        <fieldset>
          <p class="sugira-cidade">Diga-nos aonde você mora que iremos correndo atrás de você, levando descontos sensacionais.</p>
          <div style="float:left; width:290px !important;">
            <input type="text" name="cidade" id="cidade" value="DIGITE SUA CIDADE" onFocus="limpar(this);" onBlur="escrever(this);" />
          </div>
          <select  id="estado" name="estado">
            <option value="Acre">Acre</option>
<option value="Alagoas">Alagoas</option>
<option value="Amapá">Amapá</option>
<option value="Amazonas">Amazonas</option>
<option value="Bahia">Bahia</option>
<option value="Ceará">Ceará</option>
<option value="Distrito Federal">Distrito Federal</option>
<option value="Espírito Santos">Espírito Santos</option>
<option value="Goiás">Goiás</option>
<option value="Maranhão">Maranhão</option>
<option value="Mato Grosso">Mato Grosso</option>
<option value="Mato Grosso do Sul">Mato Grosso do Sul</option>
<option value="Minas Gerais">Minas Gerais</option>
<option value="Paraná">Paraná</option>
<option value="Paraíba">Paraíba</option>
<option value="Pará">Pará</option>
<option value="Pernambuco">Pernambuco</option>
<option value="Piauí">Piauí</option>
<option value="Rio Grande do Norte">Rio Grande do Norte</option>
<option value="Rio Grande do Sul">Rio Grande do Sul</option>
<option value="Rio de Janeiro">Rio de Janeiro</option>
<option value="Rondônia">Rondônia</option>
<option value="Roraima">Roraima</option>
<option value="Santa Catarina">Santa Catarina</option>
<option value="Sergipe">Sergipe</option>
<option value="São Paulo">São Paulo</option>
<option value="Tocantins">Tocantins</option>
          </select>
          <button type="submit" name="ok" id="ok">Ok</button>
        </fieldset>
      </form>
    </div>
    <div id="baixoInicio"></div>
  </div>
</div>
</head><body>
<div id="topo">
  <div id="sombrasTopo">
    <div id="contTopo">
      <h1><a href="http://www.barganhando.com/" title="Página Principal">Barganhando - as melhores empresas com os melhores descontos</a></h1>
      <div id="cidades" class="brasilia">
        <div class="escolhas"> <span class="asMelhores">As melhores ofertas de</span>
          <form name="escolha-cid" id="escolha-cid">
            <fieldset>
            
              
              <select name="cidades" id="cids" onchange="MM_jumpMenu('parent',this,0)">
                <option value="http://www.barganhando.com/index.php?cid=Brasilia" selected>Brasilia</option>
                              </select>
    
            </fieldset>
          </form>
        </div>
      </div>
      <div id="cadastroBrowser">
        <form action="http://www.barganhando.com/cadastrar/act.php?c=2" name="recebaOfertas" id="recebaOfertas" method="post" onSubmit="return validaRecebe(this)">
          <fieldset>
            <ul>
              <li>
                <label for="cid">Receba ofertas de Brasilia por email:</label>
              </li>
              <li> <span class="campo">
                <input type="text" name="email_usuario" id="email_usuario" value="DIGITE AQUI SEU EMAIL" onfocus="limpar(this);" onblur="escrever(this);" />
                <input type="hidden" name="cod_cidade" value="2" />
                </span> </li>
              <li>
                <button type="submit" name="cadastrar" id="cadastrar">cadastre-se</button>
                 </li>
            </ul>
          </fieldset>
        </form>
        <div class="clear"></div>
        <ul class="browser">
          <li class="home"><a href="#" class="home" onclick="setHomepage();">Coloque o Barganhando como página inicial</a></li>
          <li class="fav"><a href="http://barganhando.com" class="favoritos" title="Barganhando - as melhores empresas com os melhores descontos">Coloque o Barganhando nos Favoritos</a></li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
    <div id="menu-login">
      <ul id="menu">
        <li><a href="http://www.barganhando.com/" class="ativo">Oferta do dia</a></li>
        <li><a href="http://www.barganhando.com/ofertas-recentes/" >Ofertas Recentes</a></li>
        <li><a href="http://www.barganhando.com/seguranca/" >Segurança</a></li>
        <li><a href="http://www.barganhando.com/como-funciona/" >Como Funciona</a></li>
        <li><a href="http://www.barganhando.com/faq/" >Perguntas Frequentes</a></li>
      </ul>
      <div id="log">
        <ul id="login">
          <li class="login"><a href="#" id="vLogar">Login</a></li>
          <li class="conta"><a href="http://www.barganhando.com/cadastrar/">Crie uma conta</a></li>
        </ul> 
      </div>
    </div>
  </div>
</div><div id="wrap">
  <div id="inner">
    <div id="logar" style="display:none">
      <div id="innerLogar">
        <h2>Faça o login</h2>
        <form action="http://www.barganhando.com/act.php?l=1" name="formLogar" id="formLogar" method="post">
          <fieldset>
            <ul>
              <li class="campos">
                <label for="emailLogar"> Email:</label>
                <span class="ipt nome">
                <!--  value="DIGITE SEU EMAIL" -->
                <input type="text" name="email" id="emailLogar" class="validate[required,length[0,255],]" onfocus="limpar(this);" onBlur="escrever(this);" />
                </span> </li>
              <li>
                <label for="senha"> Senha:</label>
                <span class="ipt">
                <input type="password" name="senha" id="senha" class="validate[required,length[0,255],]" />
                </span> <span class="txts">Esqueceu sua senha? <a href="http://www.barganhando.com/login/">Clique aqui</a></span> </li>
                <input type="hidden" name="place" value="/index.php" />
              <li> 
                <button type="submit" name="facaLogin" id="facaLogin">faça o login</button>
              </li>
            </ul>
          </fieldset>
        </form>
        <div id="infoCadastrar">
          <h3>Ainda não é cadastrado?</h3>
          <p>Não perca tempo! Cadastre-se agora para aproveitar as melhores ofertas das melhores empresas da sua cidade.</p>
          <a href="http://www.barganhando.com/cadastrar/" class="lkn-cadastrar">Cadastrar</a> </div>
      </div>
      <a href="javascript:;" class="lkn-fechar">fechar</a> </div>    <div id="conteudo">
      <div id="colUm">
        <div id="ofertaDia">
          <h2>Oferta do dia:</h2>
          <h3>50% OFF em Tulipa de Frango ao Molho Rosé acompanhada de Cebola Tirolesa + 2 Chopps + Entrada gratuita no Chá da Boa Cervejaria. Aproveite um delicioso happy hour pela metade do preço</h3>
          <div id="itemOfertas">
            <div id="precoOferta"> <span class="detalhes-precos"></span>
              <div class="precos">
                <ul>
                  <li class="preco-normal"> <span class="bgRiscoDesconto"></span><span> 40,00 </span></li>
                  <li class="preco-desconto"> <span> 20,00 </span> </li>
                </ul>
              </div>
            </div>
                                    <a href="comprar/?c=64" rel="bookmark" title="Comprar essa Oferta" class="comprar">Comprar</a>
            <div id="tempoOferta"></div>
                                    <div class="clear"></div>
            <div id="quantidadeOferta">
              <h3>Já economizamos nesta oferta!</h3>
              <span class="preco">
			  240,00</span> <span class="vendidos">
					  12 vendido(s)</span>
					  <div id="quantidade-vendida"> <span class="inicial">0</span>
                               <div class="scroll"><span class="pc" style="margin-left:1.2%"></span></div>
                                    <span class="total">
                                        1000                                    </span> </div>
                              <div class="clear"></div>
                                                                <span class="oferta-ativa">
                                  a oferta está ativa
                                  </span>
                                                       </div>
                  </div>
          <div id="imgOferta"> <span class="seloDesconto">50%</span>
          	             <ul class="socialOferta">
              <li class="compartilhe">Compartilhe esta oferta:</li>
              <li class="twitter">
              <a href="http://twitter.com/share" class="twitter-share-button" data-url="http://bit.ly/fQwqGU" data-text="50% OFF em Tulipa de Frango ao Molho Rosé acompanhada de Cebola Tirolesa + 2 Chopps + Entrada gratuit..." data-count="none" data-via="barganhando">Tweet</a>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
              </li>
              <li class="social orkut"><a href="http://promote.orkut.com/preview?nt=orkut.com&tt=50% OFF em Tulipa de Frango ao Molho Rosé acompanhada de Cebola Tirolesa + 2 Chopps + Entrada gratuita no Chá da Boa Cervejaria. Aproveite um delicioso happy hour pela metade do preço&du=http://barganhando.com/?c=64" target="_blank">orkut</a></li>
              	
		






   
      
   
 
  


              <li>
              
              
    <div id="fb-root"></div>

  <script type="text/javascript">
      window.fbAsyncInit = function() {
        FB.init({
          appId   : '173717062672332',
          session : null, // don't refetch the session when PHP already has it
          status  : true, // check login status
          cookie  : true, // enable cookies to allow the server to access the session
          xfbml   : true // parse XFBML
        });

        // whenever the user logs in, we refresh the page
        FB.Event.subscribe('auth.login', function() {
          window.location.reload();
        });
      };

      (function() {
        var e = document.createElement('script');
        e.src = document.location.protocol + '//connect.facebook.net/pt_BR/all.js';
        e.async = true;
        document.getElementById('fb-root').appendChild(e);
      }());
    </script>
              
              
                                                                 
              <fb:like href="http://barganhando.com/?c=64" layout="button_count" show_faces="false"></fb:like> 
              
                
              </li>
            </ul>
                        <img src="files/imgs/grande_950f1e18518275856aec2f176a78e4fe.jpg" alt="img oferta" width="480" height="400" /> </div>
          <div id="empresaOferta">
            <div class="marca-empresa"><img src="files/imgs/empresa_345a50fa49bd2419c317f5ef751c60fa.jpg" alt="Chá da Boa Cervejaria" /></div>
            
            
            <div class="infos-empresa">
            
            <div class="desc-oferta">
              <h3>Descrição</h3>
              <p>      O processo de fermentação que resulta nas bebidas alcoólicas<br />
foi descoberto por acaso há, mais ou menos, 10 mil anos. Séculos<br />
se passaram e a cerveja se destaca como uma das bebidas mais<br />
apreciadas no mundo inteiro. Nós aqui do barganhando.com<br />
sabemos que você adora tomar um choppinho. Por isso, preparamos<br />
uma oferta para você se deliciar: 2 Chopps Brahma acompanhados<br />
por um prato de deliciosas tulipas de frango, petisco suave e<br />
saboroso preparado com asa de frango, onde a carne é puxada para<br />
uma das extremidades, dando o aspecto de uma tulipa. Para<br />
incrementar mais ainda, apetitosas cebolas tirolesas são servidas<br />
como acompanhamento.</p>
            </div>
            
            <div class="regras-oferta">
              <h3>Regras</h3>
              <p>- 10% já incluso no valor do cupom;<br />
<br />
- Cupom válido de 04/03/2011 a 04/05/2011;<br />
<br />
- Dias de utilização do cupom:<br />
• Terças, quartas e quintas, das 17h00 às 2h00;<br />
<br />
- Limite de dois cupons por pessoa;<br />
<br />
- O cupom deve ser utilizado no Chá da Boa Cervejaria, localizado<br />
no QSD 23 Lote 40 Loja 3.</p>
            </div>
            </div>
            
            <div class="clear"></div>
            <div id="descricoesEmpresa">
              <div class="col-um">
                <h3>Chá da Boa Cervejaria</h3>
                <a href="http://www.chadaboa.com.br/" target="_new">http://www.chadaboa.com.br/</a>
                <ul>
                  <li><a href="javascript:;">A Empresa</a></li>
                                    <li><a href="javascript:;" id="btn_localizacao">Localização</a></li>
                                    <!--  <li><a href="#">Regras</a></li>
                <li><a href="#">Saiba Mais</a></li>-->
                </ul>
              </div>
              <div class="desc">
                <h4>A Empresa</h4>
                <p>No dia 14/7 foi inaugurado o novo point de Taguatinga. O
nome“Chá da Boa” surgiu a partir de uma brincadeira entre amigos.
Para justificar às suas respectivas esposas que iriam sair para um
happy hour, diziam que iriam tomar um chá. A brincadeira pegou e
como são exímios apreciadores da cerveja Antárctica (BOA), nasceu
o “Chá da Boa”. A partir daí, surgiu a idéia de abrirem um bar com
este nome. Seus idealizadores, oferecem ao público de Taguatinga uma casa moderna, com amplo estacionamento, excelente ambiente, cocktails, petiscos variados e diferenciados, além do chopp e da cerveja mais gelados da cidade. O
“Chá da Boa” também oferece diariamente um cardápio musical de
alto nível como MPB, Pop Rock, entre outros.</p>
              </div>
                            <div class="desc">
                <h4>Localização</h4>
               <br />
			   		QSD 23  Lote 40  Loja 03 - Taguatinga Sul - Brasília/DF                    <input type="hidden" value="QSD 23  Lote 40  Loja 03 - Taguatinga Sul - Brasília/DF" id="endereco">
                    <input type="hidden" value="-15.844019" id="latitude">
                    <input type="hidden" value="-48.045353" id="longitude">             
               <br /><br />
               <div id="map_canvas" style="width:427px; height:200px"></div>
              </div>
              
                         </div>
          </div>
        </div>
      </div>
      <div id="colDois">

	<div id="sejaParceiro">
    	<h2>Seja mais um parceiro do barganhando.com.</h2>
        
        <a href="http://www.barganhando.com/seja-nosso-parceiro">Clique aqui</a>
    </div>
    
    

                      
        <div id="facebook">
          <h2>barganhando.com</h2>
          

          
          <h3>no facebook</h3>
          <iframe src="http://www.facebook.com/plugins/likebox.php?id=125607587499446&amp;width=225&amp;connections=10&amp;stream=false&amp;header=false&amp;height=340" scrolling="no" frameborder="0" style="margin-bottom: 15px;border:none; overflow:hidden; width:225px; height:340px;" allowTransparency="true"></iframe>
        </div>
        <div id="twitter">
          <h2>Twitter</h2>
          <script src="http://widgets.twimg.com/j/2/widget.js"></script> 
          <script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 3,
  interval: 6000,
  width: 225,
  height: 196,
  theme: {
    shell: {
      background: 'none',
      color: '#333333'
    },
    tweets: {
      background: '#none',
      color: '#333333',
      links: '#cc3300'
    }
  },
  features: {
    scrollbar: false,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: true,
    avatars: true,
    behavior: 'all'
  }
}).render().setUser('barganhando').start();
</script> 
          <a href="http://twitter.com/barganhando" class="lkn-siga" target="_blank">@barganhando</a> </div>
      </div>    </div>
     <div class="clear"></div>
    <div id="rodape"> <a href="http://www.barganhando.com" title="Barganhando.com" class="logoRodape">Barganhando - as melhores empresas com os melhores descontos</a>
      <ul class="lkn-rodape barganhando">
        <li>
          <h3>Barganhando.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/conheca/">Conheça</a></li>
        <li class="item"><a href="http://www.barganhando.com/termos-de-uso/">Termos de Uso</a></li>
        <li class="item"><a href="http://www.barganhando.com/contato/">Contato</a></li>
        <li class="item"><a href="http://www.barganhando.com/faq/">Perguntas Frequentes</a></li>
        <li class="item"><a href="http://www.barganhando.com/seja-nosso-parceiro/">Seja nosso parceiro</a></li>
      </ul>
      <ul class="lkn-rodape sugestoes">
        <li>
          <h3>Sugira.com</h3>
        </li>
        <li class="item"><a href="http://www.barganhando.com/sugira/">uma cidade</a></li>
        <li class="item"><a href="http://www.barganhando.com/sugira-oferta/">uma oferta</a></li>
      </ul>
      <ul class="lkn-rodape forma-pagamento">
        <li>
          <h3>Forma de Pagamento</h3> <ul>
               <li class="rede-pagt pagseguro"><a href="http://pagseguro.com.br" target="_blank">pagseguro uol</a></li>
        </ul>
        </li>
       
      </ul>
      <div class="clear"></div>
      <div class="copyright">
        <p style="float:left; width:940px;">&copy; 2011 Barganhando.com. Todos os direitos reservados</p>
        
        
        <a href="http://gori.la" title="Gori.la Comunicação Web" class="logoAgencia" target="_blank">Gori.la - Comunicação Web</a>
        
        
        
      </div>
    </div>
  </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script type="text/javascript">
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-19653867-1']);
  _gaq.push(['_trackPageview']);

(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>
